import React from "react";

export default function Movie(props) {
  console.log("props: " + props);
  return (
    <div>
      <h2>{props.title}</h2>
    </div>
  );
}
