const express = require("express");
const movieRouter = express.Router();

const uuid = require("uuid/v4");

const movies = [
  {
    title: "Conclusion",
    genre: "Sci-Fi",
    rated: "PG",
    releaseDate: "April, 2014"
  }
];

movieRouter.get("/", (req, res) => {
  res.send(movies);
});

module.exports = movieRouter;
